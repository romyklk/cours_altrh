<?php linkResource("stylesheet", "/css/style.css"); ?>

<footer>
    <div class="container-fluid bg-dark text-white mt-5">
        <div class="row">
            <div class="col-12 text-center">
                <p class="fr">Airbnb mais refait - 2023</p>
                <p class="en">Airbnb Remake - 2023</p>
                <p class="fr">Projet d'un site Airbnb refait.</p>
                <p class="en">Site project, Airbnb Remake</p>
            </div>
        </div>
    </div>
</footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
    crossorigin="anonymous"></script>
<script src="common/accueil.js"></script>

</body>

</html>