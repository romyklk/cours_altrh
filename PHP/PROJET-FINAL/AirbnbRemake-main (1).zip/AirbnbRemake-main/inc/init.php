<?php
require_once 'inc/database.php';
require_once 'inc/function.php';

session_start();

define('BASE', $_SERVER['DOCUMENT_ROOT'] . '/PHP/airbnb/UPLOADS/');

define('URL', 'http://localhost/PHP/airbnb/UPLOADS/');

define('URLUNLINK', 'UPLOADS/');

$content = '';
$linkFiltre = '';
$searchFilter = '';
