const addToCartButtons = document.querySelectorAll(".addToCart");
const cart = document.querySelector("#cart");
cart.innerText = localStorage.getItem("cartCount");
addToCartButtons.forEach((button) => {
    button.addEventListener("click", addToCart);
});

function addToCart(event) {
    if (event.target.tagName === "I") {
        let newEventTarget = event.target.closest(".addToCart");
        const productId = newEventTarget.nextElementSibling.dataset.productid;
        const cartItems = getCartItemsFromCookie();

        const existingProduct = cartItems.find(
            (item) => item.productId === productId
        );

        if (existingProduct) {
            existingProduct.quantity++;
            updateCartItemsInCookie(cartItems);
            updateCartCount();
        } else {
            const product = {
                productId: productId,
                quantity: 1,
            };

            cartItems.push(product);

            updateCartItemsInCookie(cartItems);

            updateCartCount();
        }
    } else {
        const productId = event.target.dataset.productid;
        const cartItems = getCartItemsFromCookie();

        const existingProduct = cartItems.find(
            (item) => item.productId === productId
        );

        if (existingProduct) {
            existingProduct.quantity++;
            updateCartItemsInCookie(cartItems);
            updateCartCount();
        } else {
            const product = {
                productId: productId,
                quantity: 1,
            };

            cartItems.push(product);

            updateCartItemsInCookie(cartItems);

            updateCartCount();
        }
    }
}
function getCartItemsFromCookie() {
    const cartCookie = document.cookie
        .split("; ")
        .find((row) => row.startsWith("cart="));
    if (cartCookie) {
        const cartValue = cartCookie.split("=")[1];
        return JSON.parse(decodeURIComponent(cartValue));
    }
    return [];
}
function getCartItemCount() {
    const cartItems = getCartItemsFromCookie();

    let totalCount = 0;

    cartItems.forEach((item) => {
        totalCount += item.quantity;
    });

    return totalCount;
}

function updateCartCount() {
    const totalCount = getCartItemCount();
    localStorage.setItem("cartCount", totalCount);
    const totalItems = localStorage.getItem("cartCount");
    const cartCountElement = document.getElementById("cart");
    cartCountElement.innerText = totalItems !== 0 ? totalItems.toString() : "";
}
function updateCartItemsInCookie(cartItems) {
    const cookieValue = encodeURIComponent(JSON.stringify(cartItems));
    document.cookie = `cart=${cookieValue}; path=/`;
}
