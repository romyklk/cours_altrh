<?php
$uri = $_SERVER['REQUEST_URI'];
if (!isset($_SERVER['REQUEST_URI'])) {
    $uri = '/';
}
switch ($uri) {
    case '/':
        require '../src/views/home.php';
        break;
    case '/login': 
        session_start();
        if(isset($_SESSION['login'])){
            header('Location: /');
        }  
        require '../src/views/login.php';
        break;
    
    case '/index.php/login':
        
        require '../src/functions/functions.php';
        $result = login();
        if ($result !== true) {
            $errors = $result;
            $errorsSerialized = serialize($errors);
            setcookie("errors", $errorsSerialized, time() + 3600, "/");
            header('Location: /login');
        }
    case '/user_profile':
        session_start();
        if (isset($_SESSION['login'])) {
            require '../src/views/user_profile.php';
        }else {
            header('Location: /login');
        }
        break;
    case '/logout':
        session_start();
        require '../src/functions/functions.php';
        logout();
        header('Location: /');
        break;
    case '/register':
        require '../src/views/register.php';
        break;
    case '/index.php/register':
        require '../src/functions/functions.php';
        $result = signUp();
        if ($result !== true) {
            $errors = $result;
            $errorsSerialized = serialize($errors);
            setcookie("errors", $errorsSerialized, time() + 3600, "/");
            header('Location: /register');
        }
        break;
    case '/catalogue':
        require '../src/views/catalogue.php';
        break;
    case '/cart':
        require '../src/views/cart.php';
        break;
    case '/update_profile':
        session_start();
        if (isset($_SESSION['login'])) {
           require '../src/views/user_update.php'; 
        }
        else {
            header('Location: /login');
        }
        break;
    case '/index.php/update_profile':
        session_start();
        if (isset($_SESSION['login'])) {
            require '../src/functions/functions.php';
        updateUser();
        }else {
            header('Location: /login');
        }
        break;
    case '/checkout':
        require '../src/views/checkout.php';
        break;
    default: require '../src/views/404.php';
}
// if($uri === '/') {
//     require '../src/views/home.php';

// }
// if($uri === '/login') {
//      require '../src/views/login.php';
// }
// if($uri === '/logout') {
//     session_destroy();
//     header('Location: /');
// }
// if($uri === '/register') {
//     require '../src/views/register.php';
// }
// if($uri === '/index.php/register') {
//     require '../src/functions/functions.php';
//     $result = signUp();
//     if ($result ===$userinfo) {
        

//     } else {
//         $errors = $result;
//         $errorsSerialized = serialize($errors);
//         setcookie("errors", $errorsSerialized, time() + 3600, "/");
//         header('Location: /register');
//     }

// }

// if($uri === '/catalogue') {
//     require '../src/views/catalogue.php';
// }
// require'../src/views/404.php';
var_dump(parse_url($_SERVER['REQUEST_URI']));