<footer>
    <ul class="social-icons">
        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
    </ul>
    <p class="copyright">
        &copy; 2023 Mon Entreprise. Tous droits réservés.
    </p>
</footer>



</body>

</html>