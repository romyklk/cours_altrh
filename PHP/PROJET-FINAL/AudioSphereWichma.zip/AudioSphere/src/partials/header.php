<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/d5442c2068.js" crossorigin="anonymous" defer></script>
    <script src="./index.js" defer></script>
    <title>AudioSphere</title>

</head>

<body>


    <nav class="navbar">
        <div class="logo">
            <h1><a href="/">AudioSphere</a></h1>
        </div>

        <ul class="menu">
            <li><a href="/" class="active">Accueil</a></li>
            <li><a href="/cart" id="cart" class="fa-solid fa-cart-shopping"><span id="cartCount"></span></a></li>
            <li><a href="<?php echo isset($_SESSION['login']) ? '/user_profile' : '/login' ?>" class="fa-solid fa-user"></a></li>
            <?php if (isset($_SESSION['login'])) : ?>
                <li><a href="/logout" class="fa-solid fa-right-from-bracket"></a></li>
            <?php endif; ?>
        </ul>
    </nav>