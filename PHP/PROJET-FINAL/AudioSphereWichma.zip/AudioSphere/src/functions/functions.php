<?php
function ConnectDb()
{
    $dsn = "mysql:host=localhost;dbname=audiosphere";
    $user = "root";
    $password = "";
    try {
        $con = new PDO($dsn, $user, $password);
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $con;
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}
function signUp()
{
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $error = [];
        foreach ($_POST as $key => $value) {
            $_POST[$key] = htmlspecialchars(addslashes($value));
        }

        $lastname = $_POST['lastname'];
        $firstname = $_POST['firstname'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $sexe = $_POST['gender'];
        $password = $_POST['password'];
        $password_confirm = $_POST['confirmpassword'];
        if (empty($lastname)) {
            $error["lastname"] = 'Veuillez renseigner votre nom';
        }
        if (empty($firstname)) {
            $error["firstname"] = 'Veuillez renseigner votre prenom';
        }
        if (empty($username)) {
            $error["username"] = 'Veuillez renseigner votre pseudo';
        }
        if (empty($email)) {
            $error["email"] = 'Veuillez renseigner votre email';
        }
        if (empty($sexe)) {
            $error["sexe"] = 'Veuillez renseigner votre sexe';
        }
        if (empty($password)) {
            $error["password"] = ' mot de passe obligatoire';
        }
        if (empty($password_confirm || $password !== $password_confirm)) {
            $error["password_confirm"] = 'les mot de passe doivent être identiques';
        } else {
            $password = password_hash($password, PASSWORD_DEFAULT);
        }
        if (!empty($error)) {
            return $error;
        }
        try {

            $con = ConnectDb();
            $sql = "INSERT INTO users (last_name, first_name, username, email, sexe, password) VALUES (:lastname, :firstname, :username, :email, :sexe, :password)";
            $stmt = $con->prepare($sql);
            $stmt->bindParam(':lastname', $lastname);
            $stmt->bindParam(':firstname', $firstname);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':sexe', $sexe);
            $stmt->bindParam(':password', $password);
            $stmt->execute();
            if ($stmt) {
                session_start();
                $newsql = "SELECT * FROM users WHERE username = :username";
                $newstmt = $con->prepare($newsql);
                $newstmt->bindParam(':username', $username);
                $newstmt->execute();
                $newUser = $newstmt->fetch(PDO::FETCH_ASSOC);
                if(!empty($newUser)){
                $_SESSION['login'] = $newUser;
                }
                return true;
            }
        } catch (PDOException $e) {
            return $error['db'] = $e->getMessage();
        }
    }
}



function login()
{
    $error = [];
    session_start();
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        foreach ($_POST as $key => $value) {
            $_POST[$key] = htmlspecialchars(addslashes($value));
        }
        $email = $_POST['email'];
        $password = $_POST['password'];
        if (empty($email)) {
            $error["email"] = ' Email ou Pseudo';
        }
        if (empty($password)) {
            $error["password"] = ' Mot de passe';
        }
        if (empty($error)) {
            try {
                $con = ConnectDb();
                $sql = "SELECT * FROM users WHERE email = :email or username = :username";
                $stmt = $con->prepare($sql);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':username', $email);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!empty($user)) {
                    if (password_verify($password, $user['password'])) {
                        $_SESSION['login'] = $user;
                        header('Location: /');
                        return true;
                    }
                }
                $error["message"] = "Mot de passe ou Pseudo incorrect";;
            } catch (PDOException $e) {
                return $error['db'] = $e->getMessage();
            }
        }
        return $error;
    }
}


function logout()
{
    session_destroy();
}

function updateUser()
{
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        foreach ($_POST as $key => $value) {
            $_POST[$key] = htmlspecialchars(addslashes($value));
        }
        try {
            $pdo = ConnectDb();

            $userId = $_SESSION['login']['user_id'];

            
            $sql = "UPDATE Users SET ";

            $fields = [];
            foreach ($_POST as $key => $value) {
                if (!empty($value) && $key !== 'user_id') {
                    $fields[] = "$key = :$key";
                }
            }

            $sql .= implode(", ", $fields);
            $sql .= " WHERE user_id = :user_id";

            
            $stmt = $pdo->prepare($sql);

          
            foreach ($_POST as $key => $value) {
                if (!empty($value) && $key !== 'user_id') {
                    $stmt->bindValue(":$key", $value);
                }
            }
            $stmt->bindParam(':user_id', $userId);

           
            $stmt->execute();


            if ($stmt->rowCount() > 0) {
                $sql = "SELECT * FROM Users WHERE user_id = :user_id";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':user_id', $userId);
                $stmt->execute();
                $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);

    
                $_SESSION['login'] = $updatedUser;
                return true;


                return $_SESSION['login'];
            } else {
                return false;

           
        } 
       $pdo = null;  
    }catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
}}
