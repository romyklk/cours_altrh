<?php
require '../src/partials/header.php';
require '../src/functions/functions.php';
$pdo = ConnectDb();
$sql = "SELECT * FROM products";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<section class="content">
    <h1 class="Produits_texte">Nos meilleures ventes</h1>
    <p>Notre catalogue nouveautés avec des technologies les plus avancés</p>
    <button><a href="/catalogue" style="text-decoration: none; color: black;">Decouvrir</a></button>
</section>


<h1 class="Produits_texte">Nos meilleures ventes</h1>
<section class="section_produits">

    <div class="produits">
        <?php foreach ($products as $product) : ?>
            <div class="carte">
                <div class="img"><img src="./uploads/products_img/<?php echo $product['product_img']; ?>">
                    <div class="titre"><?php echo $product['name']; ?> </div>
                    <div class="product-desc"><?php echo $product['description']; ?></div>
                    <div class="box">
                        
                        <div class="prix"><?php echo $product['price'] . ' €'; ?></div>
                        <button  class="achat addToCart"><i class="fa-solid fa-cart-shopping"></i></button><span style="display: none;" data-productid="<?php echo $product['product_id']; ?>"></span>
                        <button class="achat"><a class="achat" href="/checkout?id=<?php echo $product['product_id']; ?>">Acheter</a></button>
                    </div>

                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php
require '../src/partials/footer.php';
?>