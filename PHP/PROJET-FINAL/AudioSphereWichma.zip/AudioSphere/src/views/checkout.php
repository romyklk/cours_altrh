<?php
require '../src/partials/header.php';
?>
<?php
require '../src/partials/footer.php';
?>