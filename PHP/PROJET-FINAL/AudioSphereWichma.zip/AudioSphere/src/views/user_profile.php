<?php
require '../src/partials/header.php';
if (isset($_SESSION['login'])) {
    $user = $_SESSION['login'];
}
?>
<div class="form-container">
    <div class="container">
        <div class="title">Profile</div>
        <hr style="margin-bottom: 10px;">
        <h6>User Info</h6>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="user-details">
                <div class="input-box">
                    <span class="details">Prenom</span>
                    <input type="text" name="firstname" value="<?php echo $user['first_name']; ?>" readonly />
                </div>

                <div class="input-box">
                    <span class="details">Nom</span>
                    <input type="text" name="lastname" placeholder="Enter your lastname" value="<?php echo $user['last_name']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Email</span>
                    <input type="text" name="email" placeholder="Enter your email" value="<?php echo $user['email']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Username</span>
                    <input type="text" name="username" placeholder="Enter your username" value="<?php echo $user['username']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Numero</span>
                    <input type="text" name="username" value="<?php echo $user['phone_number']; ?>" readonly />
                </div>

                <div class="gender-details">
                    <input type="radio" value="Homme" name="gender" id="dot-1" <?php if (isset($_POST['gender']) && $_POST['gender'] == 'Homme') echo 'checked'; ?> readonly />
                    <input type="radio" value="Femme" name="gender" <span class="gender-title">Gender</span>
                    <div class="category">

                        <label for="dot-1">
                            <span class="dot one"></span>
                            <span class="Gender"><?= $user['sexe']; ?></span>
                        </label>


                    </div>
                </div>
            </div>
            <hr style="margin-bottom: 10px;">
            <h6>Addresse</h6>
            <div class="user-details">

                <div class="input-box">
                    <span class="details">Adresse</span>
                    <input type="text" name="address" value="<?php echo $user['address']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Ville</span>
                    <input type="text" name="city" value="<?php echo $user['city']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Pays</span>
                    <input type="text" name="country" value="<?php echo $user['country']; ?>" readonly />
                </div>
                <div class="input-box">
                    <span class="details">Code Postal</span>
                    <input type="text" name="postal_code" value="<?php echo $user['postal_code']; ?>" readonly />
                </div>


            </div>
        </form>
        <span style="display: block ;text-align: center"><a class="btn" href="/update_profile"> Modifier votre profil </a></span>
    </div>
</div>

<?php
require '../src/partials/footer.php';
?>