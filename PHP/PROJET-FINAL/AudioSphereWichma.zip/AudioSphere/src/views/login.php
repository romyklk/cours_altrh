<?php
require '../src/partials/header.php';
if (isset($_COOKIE['errors'])) {
    $errorsSerialized = $_COOKIE['errors'];
    $errors = unserialize($errorsSerialized);



    setcookie("errors", "", time() - 3600, "/");
}
?>
<div class="form-container">
    <div class="container">
        <div class="title">Se Connecter</div>
        <span style="display: block ;text-align: center; color: red"><?= $errors['message'];?> </span>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="user-details">

                <div class="input-box">
                    <span class="error"> <?= $errors['email']; ?></span>
                    <span class="details">Email ou Pseudo</span>
                    <input type="text" name="email" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" />
                </div>

                <div class="input-box">
                    <span class="error"><?= $errors['password']; ?></span>
                    <span class="details">Password</span>
                    <input type="password" name="password" placeholder="Enter your password" />
                </div>

            </div>

            <div class="button">
                <input type="submit" value="se connecter" />
            </div>
            <span style="display: block ;text-align: center">Vous n'avez pas de compte ? <a style="text-decoration: none;
    color: black" href="/register"> S'inscrire </a></span>
        </form>
    </div>
</div>
<?php
require '../src/partials/footer.php'
?>