<?php
require '../src/partials/header.php';
require '../src/functions/functions.php';

$cartItems = $_COOKIE['cart'] ?? [];

$pdo = ConnectDb();
$products = [];

if (!empty($cartItems)) {

    $productIds = array_column($cartItems, 'productId');


    $placeholders = implode(',', array_fill(0, count($productIds), '?'));


    $query = "SELECT * FROM products WHERE product_id IN ($placeholders)";
    $stmt = $pdo->prepare($query);


    $stmt->execute($productIds);


    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $products[] = $row;
    }
}


?>
<?php foreach ($products as $product) : ?>
    <div class="product">
        <div class="product-image">
            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
        </div>
        <div class="product-details">
            <h2 class="product-name"><?php echo $product['name']; ?></h2>
            <p class="product-description"><?php echo $product['description']; ?></p>
            <p class="product-price"><?php echo $product['price']; ?> €</p>
            <button class="add-to-cart" data-product-id="<?php echo $product['product_id']; ?>">Add to Cart</button>
        </div>
    </div>
<?php endforeach; ?>
<?php
require '../src/partials/footer.php';
?>