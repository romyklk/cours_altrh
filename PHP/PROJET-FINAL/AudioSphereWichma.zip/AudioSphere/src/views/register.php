<?php
require '../src/partials/header.php';
if (isset($_COOKIE['errors'])) {
    $errorsSerialized = $_COOKIE['errors'];
    $errors = unserialize($errorsSerialized);

var_dump($errors);

    setcookie("errors", "", time() - 3600, "/");
}


?>
<div class="form-container">
    <div class="container">
        <div class="title">S'inscrire</div>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="user-details">
                <div class="input-box">
                    <span class="error"></span><?= $errors['firstname']; ?></span>
                    <span class="details">Prenom</span>
                    <input type="text" name="firstname" placeholder="Enter your firstname" value="<?php echo isset($_POST['firstname']) ? $_POST['firstname'] : ''; ?>" />
                </div>

                <div class="input-box">
                    <span class="error"><?= $errors['lastname']; ?></span>
                    <span class="details">Nom</span>
                    <input type="text" name="lastname" placeholder="Enter your lastname" value="<?php echo isset($_POST['lastname']) ? $_POST['lastname'] : ''; ?>" />
                </div>
                <div class="input-box">
                    <span class="error"> <?= $errors['email']; ?></span>
                    <span class="details">Email</span>
                    <input type="text" name="email" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" />
                </div>
                <div class="input-box">
                    <span class="error"><?= $errors['username']; ?></span>
                    <span class="details">Username</span>
                    <input type="text" name="username" placeholder="Enter your username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>" />
                </div>
                <div class="input-box">
                    <span class="error"><?= $errors['password']; ?></span>
                    <span class="details">Password</span>
                    <input type="password" name="password" placeholder="Enter your password" />
                </div>
                <div class="input-box">
                    <span class="error"><?= $errors['password_confirm']; ?></span>
                    <span class="details">Confirm password</span>
                    <input type="password" name="confirmpassword" placeholder="Confirm your password" />
                </div>
            </div>
            <div class="gender-details">
                <input type="radio" value="Homme" name="gender" id="dot-1" <?php if (isset($_POST['gender']) && $_POST['gender'] == 'Homme') echo 'checked'; ?> />
                <input type="radio" value="Femme" name="gender" id="dot-2" <?php if (isset($_POST['gender']) && $_POST['gender'] == 'Femme') echo 'checked'; ?> />
                <span style="display: block"><?= $errors['sexe']; ?></span>
                <span class="gender-title">Gender</span>
                <div class="category">
                    
                    <label for="dot-1">
                        <span class="dot one"></span>
                        <span class="Gender">Homme</span>
                    </label>

                    <label for="dot-2">
                        <span class="dot two"></span>
                        <span class="Gender">Femme</span>
                    </label>
                </div>
            </div>
            <div class="button">
                <input type="submit" value="enregistrer" />
            </div>
        </form>
        <span style="display: block ;text-align: center">Vous avez déjà un compte ? <a style="text-decoration: none; color: black" href="/login"> Connectez-vous ! </a></span>
    </div>
</div>
<?php
require '../src/partials/footer.php';
?>