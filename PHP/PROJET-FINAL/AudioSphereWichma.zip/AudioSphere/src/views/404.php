<?php
require '../src/partials/header.php';
?>

<div class="error-container">
    <div class="error-code">404</div>
    <div class="error-message">Page Not Found</div>
</div >
<?php
require '../src/partials/footer.php';
?>