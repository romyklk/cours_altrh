<?php
require '../src/partials/header.php';
if (isset($_SESSION['login'])) {
    $user = $_SESSION['login'];
}
?>
<div class="form-container">
    <div class="container">
        <div class="title">Profile</div>
        <hr style="margin-bottom: 10px;">
        <h6>User Info</h6>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="user-details">
                <div class="input-box">
                    <span class="details">Prenom : <?php echo $user['first_name']; ?> </span>
                    <input type="text" name="first_name"  />
                </div>

                <div class="input-box">
                    <span class="details">Nom: <?php echo $user['last_name']; ?></span>
                    <input type="text" name="last_name"  />
                </div>
                <div class="input-box">
                    <span class="details">Email: <?php echo $user['email']; ?> </span>
                    <input type="text" name="email"  />
                </div>
                <div class="input-box">
                    <span class="details">Username: <?php echo $user['username']; ?> </span>
                    <input type="text" name="username" />
                </div>
                <div class="input-box">
                    <span class="details">Numero :<?php echo $user['phone']; ?> </span>
                    <input type="text" name="phone_number"  />
                </div>
                <div class="input-box">
                    <span class="details">Mot de passe</span>
                    <input type="password" name="password" autocomplete="false"/>
                </div>

            </div>
            <hr style="margin-bottom: 10px;">
            <h6>Addresse</h6>
            <div class="user-details">

                <div class="input-box">
                    <span class="details">Adresse: <?php echo $user['address']; ?></span>
                    <input type="text" name="address"  />
                </div>
                <div class="input-box">
                    <span class="details">Ville: <?php echo $user['city']; ?></span>
                    <input type="text" name="city"  />
                </div>
                <div class="input-box">
                    <span class="details">Pays: <?php echo $user['contry']; ?></span>
                    <input type="text" name="country"  />
                </div>
                <div class="input-box">
                    <span class="details">Code Postal: <?php echo $user['postal_code']; ?></span>
                    <input type="text" name="postal_code"  />
                </div>


            </div>
            <div style="text-align: center"><input class="btn" type="submit" value="Modifier"></div>
        </form>

    </div>
</div>

<?php
require '../src/partials/footer.php';
?>