<?php 
$nomPage = str_replace('action=inscription', "", $nomFichier);
if (substr($nomPage, -1) === '&') {
    // Supprimer le dernier caractère "&"
    $nomPage = substr($nomPage, 0, -1);
}



// Traitement du formulaire avec server request method
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach($_POST as $key => $value){
        $_POST[$key] = htmlspecialchars(addslashes($value));
    }

    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
    $pseudo = isset($_POST['pseudo']) ? $_POST['pseudo'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $passwordconfirm = isset($_POST['passwordConfirm']) ? $_POST['passwordConfirm'] : '';

    $errors = [];

    $query = $db->prepare('SELECT pseudo FROM user WHERE pseudo = :pseudo');
    $query->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
    $query->execute();
    $user = $query->rowCount();

    $query = $db->prepare('SELECT mail FROM user WHERE mail = :email');
    $query->bindValue(':email', $email, PDO::PARAM_STR);
    $query->execute();
    $mail = $query->rowCount();

    if (empty($name)) {
        $errors['name'] = 'Veuillez renseigner votre nom';
    }
    if (empty($firstname)) {
        $errors['firstname'] = 'Veuillez renseigner votre prénom';
    }
    if (empty($pseudo)) {
        $errors['pseudo'] = 'Veuillez renseigner votre pseudo';
    } elseif ($user > 0) {
        $errors['pseudo'] = 'Ce pseudo existe déjà';
    }
    if (empty($email)) {
        $errors['email'] = 'Veuillez renseigner votre email';
    } elseif ($mail > 0) {
        $errors['email'] = 'Cet email est déjà pris';
    }
    if (empty($password)) {
        $errors['password'] = 'Veuillez renseigner votre mot de passe';
    }
    if (empty($passwordconfirm)) {
        $errors['passwordConfirm'] = 'Veuillez confirmer votre mot de passe';
    } elseif ($password != $passwordconfirm) {
        $errors['passwordConfirm'] = 'Les mots de passe ne correspondent pas';
    }

    if (empty($errors)) {
        $query = $db->prepare('INSERT INTO user (name, firstname, pseudo, mail, password) VALUES (:name, :firstname, :pseudo, :email, :password)');
        $query->bindValue(':name', $name);
        $query->bindValue(':firstname', $firstname);
        $query->bindValue(':pseudo', $pseudo);
        $query->bindValue(':email', $email);
        $query->bindValue(':password', password_hash($password, PASSWORD_DEFAULT));
        $query->execute();
        header('Location: index.php?action=connexion');
    } 
}

?>


<div class="pop-up">
    <div class="container">
        <h3 class="text-center">Inscription</h3>
        <form method="POST">
            <div class="mb-3">
                <label for="name">Nom</label>
                <input type="text" class="form-control" id="name" placeholder="Entrez votre nom" name="name" value="<?php if(isset($_POST['name'])) echo $_POST['name'];?>">
                <?php if(isset($errors['name'])) echo '<p class="text-danger">' . $errors['name'] . '</p>'; ?>
            </div>
            <div class="mb-3">
                <label for="firstname">Prénom</label>
                <input type="text" class="form-control" id="firstname" placeholder="Entrez votre prénom" name="firstname" value="<?php if(isset($_POST['firstname'])) echo $_POST['firstname'];?>">
                <?php if(isset($errors['firstname'])) echo '<p class="text-danger">' . $errors['firstname'] . '</p>'; ?>
            </div>
            <div class="mb-3">
                <label for="pseudo">Pseudo</label>
                <input type="text" class="form-control" id="pseudo" placeholder="Entrez votre pseudo" name="pseudo" value="<?php if(isset($_POST['pseudo'])) echo $_POST['pseudo'];?>">
                <?php if(isset($errors['pseudo'])) echo '<p class="text-danger">' . $errors['pseudo'] . '</p>'; ?>
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1">Adresse email</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre adresse email" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>">
                <?php if(isset($errors['email'])) echo '<p class="text-danger">' . $errors['email'] . '</p>'; ?>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1">Mot de passe</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre mot de passe" name="password">
                <?php if(isset($errors['password'])) echo '<p class="text-danger">' . $errors['password'] . '</p>'; ?>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword2">Confirmez votre mot de passe</label>
                <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Confirmez votre mot de passe" name="passwordConfirm">
                <?php if(isset($errors['passwordConfirm'])) echo '<p class="text-danger">' . $errors['passwordConfirm'] . '</p>'; ?>
            </div>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">S'inscrire</button>
                <a class="btn btn-danger" href="<?= $nomPage ?>">Retour</a>
            </div>


        </form>
    </div>  
</div>