<?php $nomFichier = $_SERVER['REQUEST_URI'];
require_once('inc/init.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <?php require_once('common/style.php'); ?>
</head>

<?php 
if (isset($_GET['action'])) {
  $action = $_GET['action'];
} else {
  $action = NULL;
}


if ($action == 'connexion') {
  require_once('common/connexion.php');
} elseif ($action == 'inscription') {
  require_once('common/inscription.php');
}
if ($action == 'deconnexion') {
  session_destroy();
  header("Location: index.php");
}

?>


<body>


<nav id="navbar" class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="./index.php">
        <img src="./images/logo_leboncote.png" alt="logo" class="logo" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto" >
      <li class="nav-item" >
        <a class="btn btn-success" role="button" href="ajout_annonce.php"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
</svg> Déposer une annonce</a></button>
      </li>
    </ul>
    <ul class="navbar-nav ms-auto">
      <?php if(isset($_SESSION['user'])) : ?>

      <li class="nav-item">
        <a class="nav-link" href="compte.php">Mon compte</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=$nomFichier?><?php
        if (strpos($nomFichier, '?') !== false) {
          echo '&';
        } else {
          echo '?';
        }
        ?>
      action=deconnexion">Déconnexion</a>
      </li>

      <?php else : ?> 
      <li class="nav-item">
        <a class="nav-link" href="<?=$nomFichier?><?php
        if (strpos($nomFichier, '?') !== false) {
          echo '&';
        } else {
          echo '?';
        }
        ?>action=connexion">Connexion</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=$nomFichier?><?php
        if (strpos($nomFichier, '?') !== false) {
          echo '&';
        } else {
          echo '?';
        }
        ?>action=inscription">Inscription</a>
      </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>