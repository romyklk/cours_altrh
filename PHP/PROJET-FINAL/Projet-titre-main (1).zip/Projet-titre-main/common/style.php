
<style>
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

body {
    min-height: 100vh;
}


.logo {
    width: 150px;
    max-width: 25vw;
}

.pop-up {
    margin-top: 0;
    width: 100vw;
    height: 100vh;
    z-index: 1000;
    position: fixed;
    top: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.pop-up .container {
    width: 50%;
    min-height: 50%;
    padding: 15px 0;
    background-color: #fff;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

h3 {
    font-family: 'Bebas Neue', sans-serif;
}

p, .card-text {
    font-family: 'Roboto', sans-serif;
}

.lienProfil a{
    color: blue;
    text-decoration: none;
    text-align: center;
}

.lienProfil {
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
</style>
