<?php

if(!isLogged()){
    header('Location: profil.php?pseudo='.$pseudo);
    exit;
}


//Traitement du formulaire
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    foreach($_POST as $key => $value){
        $_POST[$key] = htmlspecialchars(addslashes($value));
    }
    
    $avis = isset($_POST['avis']) ? $_POST['avis'] : '';
    $etoile = isset($_POST['etoiles']) ? $_POST['etoiles'] : '';

    $errors = [];

    if(empty($avis)){
        $errors['avis'] = "L'avis est obligatoire";
    }
    if(empty($etoile)){
        $errors['etoiles'] = "La note est obligatoire";
    }

    if ($etoile < 1 || $etoile > 5) {
        if ($etoile < 1) {
            $etoile = 1;
        } else {
            $etoile = 5;
        }
    }

    $query = $db->prepare('SELECT id_user FROM user WHERE pseudo = :pseudo');
    $query->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
    $query->execute();
    $id_user_b = $query->fetch(PDO::FETCH_ASSOC);
    $id_user_b = $id_user_b['id_user'];


    $id_user = $_SESSION['user']['id'];

    if ($id_user == $id_user_b) {
        $errors['id'] = 'Vous ne pouvez pas vous noter vous même';
    }

    
    //Si pas d'erreurs
    if(empty($errors)){

        $query = $db->prepare('INSERT INTO avis (id_user, id_user_b, avis, etoiles) VALUES (:id_user, :id_user_b, :avis, :etoiles)');
        $query->bindValue(':id_user', $id_user, PDO::PARAM_INT);
        $query->bindValue(':id_user_b', $id_user_b, PDO::PARAM_INT);
        $query->bindValue(':avis', $avis, PDO::PARAM_STR);
        $query->bindValue(':etoiles', $etoile, PDO::PARAM_STR);
        
        if ($query->execute()) {
            header('Location: profil.php?pseudo='.$pseudo);
        } else {
            $errors['query'] = 'Erreur lors de l\'ajout de l\'avis';
        }
        //Redirection
        
    }
}  
?>


<div class="pop-up">
<div class="container">
    <h3> Laisser un avis </h3>
<form id="avisForm" action="" method="POST">
    <div class="form-group">
        <label for="avis">Avis :</label>
        <?php if(isset($errors['avis'])) {
            foreach($errors as $error) {
                echo '<p class="text-danger">'.$error.'</p>';
            }
        } 
            ?>    
        <textarea class="form-control" id="avis" name="avis" placeholder="Avis" ></textarea>
    </div>
    <div class="form-group">
        <label for="etoiles">Étoiles :</label>
            <select class="form-select" aria-label="Default select example" name="etoiles">
                <option selected>Nombre d'Étoiles</option>
                <option value="1">⭐</option>
                <option value="2">⭐⭐</option>
                <option value="3">⭐⭐⭐</option>
                <option value="4">⭐⭐⭐⭐</option>
                <option value="5">⭐⭐⭐⭐⭐</option>

            </select>
        
    </div>
    <button type="submit" class="btn btn-success mt-3">Soumettre</button>
    <a href="profil.php?pseudo=<?= $pseudo ?>" class="btn btn-danger mt-3">Annuler</a>
</form>
</div>
</div>

