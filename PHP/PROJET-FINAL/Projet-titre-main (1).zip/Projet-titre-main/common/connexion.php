<?php 
$nomPage = str_replace("action=connexion", "", $nomFichier);
if (substr($nomPage, -1) === '&') {
    // Supprimer le dernier caractère "&"
    $nomPage = substr($nomPage, 0, -1);
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    foreach($_POST as $key => $value){
        $_POST[$key] = htmlspecialchars(addslashes($value));
    }

    $pseudo = isset($_POST['pseudo']) ? $_POST['pseudo'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $errors = [];

    if(empty($pseudo)){
        $errors['pseudo'] = 'Veuillez renseigner votre pseudo';
    }
    if(empty($password)){
        $errors['password'] = 'Veuillez renseigner votre mot de passe';
    }

    if(empty($errors)){
        $query = $db->prepare('SELECT * FROM user WHERE pseudo = :pseudo');
        $query->bindValue(':pseudo', $pseudo);
        $query->execute();
        $user = $query->fetch();

        if($user && password_verify($password, $user['password'])){
            $_SESSION['user'] = [
                'id' => $user['id_user'],
                'name' => $user['name'],
                'firstname' => $user['firstname'],
                'pseudo' => $user['pseudo'],
                'mail' => $user['mail'],
                'password' => $user['password'],
                'createdAt' => $user['createdAt']
            ];
            header("Location: $nomPage");
        } else {
            $errors['password'] = 'Identifiants incorrects';
        }
    }
}

?>




<div class="pop-up">
    <div class="container">
        <h3 class="text-center">Connexion</h3>
        <form method="post">
            <div class="mb-3">
                <label for="pseudo">Pseudo</label>
                <input type="text" class="form-control" id="pseudo" placeholder="Entrez votre pseudo" name="pseudo" value="<?php if(isset($_POST['pseudo'])) echo $_POST['pseudo'];?>"> 
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1">Mot de passe</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre mot de passe" name="password">
            </div>
            <?php
            // si erreur, n les affiche :
            if(!empty($errors)){
                foreach($errors as $error){
                    echo '<p class="text-danger">' . $error . '</p>';
                }
            }
            ?>
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Se connecter</button>
                <a class="btn btn-danger" href="<?= $nomPage ?>">Retour</a>
            </div>


        </form>
    </div>  
</div>