<?php 

function isLogged(){
    if(isset($_SESSION['user']) && !empty($_SESSION['user'])){
        return true;
    }else{
        return false;
    }
}

function mois($moi){
    $numero = $moi; // Numéro de la personne que vous souhaitez récupérer

    $mois = array(
        '01' => 'Janvier',
        '02' => 'Février',
        '03' => 'Mars',
        '04' => 'Avril',
        '05' => 'Mai',
        '06' => 'Juin',
        '07' => 'Juillet',
        '08' => 'Août',
        '09' => 'Septembre',
        '10' => 'Octobre',
        '11' => 'Novembre',
        '12' => 'Décembre'
    );

    return $mois[$numero];
}

function etoiles($etoile){
    $nombre = $etoile;

    $etoiles = array(
        '1' => '⭐',
        '2' => '⭐⭐',
        '3' => '⭐⭐⭐',
        '4' => '⭐⭐⭐⭐',
        '5' => '⭐⭐⭐⭐⭐'
    );

    return $etoiles[$nombre];
}


?>