<?php require_once('inc/config.php'); 
require_once('inc/fonctions.php');
session_start();
?>
