-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 22 juin 2023 à 13:58
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_titre`
--

-- --------------------------------------------------------

--
-- Structure de la table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
CREATE TABLE IF NOT EXISTS `annonce` (
  `id_annonce` int NOT NULL AUTO_INCREMENT,
  `id_user` int NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `categorie` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `date_ajout` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_annonce`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `annonce`
--

INSERT INTO `annonce` (`id_annonce`, `id_user`, `titre`, `categorie`, `price`, `description`, `date_ajout`) VALUES
(19, 12, 'Voiture', 'vehicule', '900', 'À vendre : Voiture d\'occasion en excellent état. Marque, modèle, année, kilométrage, et prix disponibles. Bien entretenue et fiable. Pour plus d\'infos, contactez-moi. Faites vite, offre limitée !', '2023-06-22 09:40:29'),
(20, 13, 'Appartement Franconville', 'immobilier', '950', 'À louer : Appartement spacieux au cœur du centre-ville de Franconville. Emplacement idéal à proximité des commerces, des transports en commun et des commodités. L\'appartement offre des pièces lumineuses et bien agencées, avec une cuisine entièrement équipée et une salle de bains moderne. La résidence est sécurisée et dispose d\'un ascenseur. Ne manquez pas cette opportunité de vivre dans un appartement confortable au cœur de Franconville. Contactez-nous dès maintenant pour organiser une visite.', '2023-06-22 09:41:40'),
(21, 14, 'Vélo', 'vehicule', '700', 'KIZEHJDGCVZKIEHYFDGVGZE UFZE FZEUOy fgAZOEUF DGZSOUEFG ', '2023-06-22 15:40:59');

-- --------------------------------------------------------

--
-- Structure de la table `avis`
--

DROP TABLE IF EXISTS `avis`;
CREATE TABLE IF NOT EXISTS `avis` (
  `id_avis` int NOT NULL AUTO_INCREMENT,
  `id_user` int NOT NULL,
  `id_user_b` int NOT NULL,
  `avis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `etoiles` int NOT NULL,
  PRIMARY KEY (`id_avis`),
  KEY `id_user_b` (`id_user_b`),
  KEY `id_user_avis` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `avis`
--

INSERT INTO `avis` (`id_avis`, `id_user`, `id_user_b`, `avis`, `date`, `etoiles`) VALUES
(30, 14, 12, 'Super vendeur', '2023-06-22 15:41:26', 3);

-- --------------------------------------------------------

--
-- Structure de la table `conv`
--

DROP TABLE IF EXISTS `conv`;
CREATE TABLE IF NOT EXISTS `conv` (
  `id_conv` int NOT NULL AUTO_INCREMENT,
  `id_user_a` int NOT NULL,
  `id_user_b` int NOT NULL,
  PRIMARY KEY (`id_conv`),
  KEY `id_user_conv` (`id_user_a`),
  KEY `id_user_b_conv` (`id_user_b`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `conv`
--

INSERT INTO `conv` (`id_conv`, `id_user_a`, `id_user_b`) VALUES
(8, 13, 12),
(9, 14, 12);

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id_images` int NOT NULL AUTO_INCREMENT,
  `id_annonce` int NOT NULL,
  `chemin_image` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_images`),
  KEY `id_annonce_b` (`id_annonce`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `images`
--

INSERT INTO `images` (`id_images`, `id_annonce`, `chemin_image`) VALUES
(8, 19, 'images/d9b01d4c51b60d21bcf26ba6ea6a687d.jpg'),
(9, 20, 'images/5d09d9da1b486e852d517a7c2bf49f4b.jpg'),
(10, 21, 'images/1fff3b43b2eb7ad0a25227fb9af8a371.jpeg');

-- --------------------------------------------------------

--
-- Structure de la table `mesages`
--

DROP TABLE IF EXISTS `mesages`;
CREATE TABLE IF NOT EXISTS `mesages` (
  `id_message` int NOT NULL AUTO_INCREMENT,
  `id_conv` int NOT NULL,
  `id_user` int NOT NULL,
  `contenu` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_message`),
  KEY `id_conv` (`id_conv`),
  KEY `re_id_user_encore` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `mesages`
--

INSERT INTO `mesages` (`id_message`, `id_conv`, `id_user`, `contenu`) VALUES
(17, 8, 13, 'Bonjour à vous'),
(18, 8, 12, 'Hello'),
(19, 8, 12, 'C\'est pour quoi?'),
(20, 9, 14, 'Je suis interessé par votre annonce '),
(21, 9, 12, 'Bien sur !');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `pseudo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id_user`, `name`, `firstname`, `pseudo`, `mail`, `password`, `createdAt`) VALUES
(12, 'Doe', 'John', 'jdoe', 'bemini2655@peogi.com', '$2y$10$CPwecj04iNUSCj82wzwLCelqiCHOLSGe6SDzANXrvzglZrpNB5vnm', '2023-06-22 09:37:51'),
(13, 'Doe', 'Jane', 'janed', 'mosayow230@pyadu.com', '$2y$10$JqYONneU3gRSfeivMv0.4u3JiLCDiTmaRWVUA/7NqIavPeslZc5.S', '2023-06-22 09:40:49'),
(14, 'User', 'Michel', 'GML', 'qsdqsdqqs@gmail.com', '$2y$10$atgWBdv6ZzQhzkqrtRjDmOrTynK31Wwqv5bZG/1xuOQwhJ4py.rGq', '2023-06-22 15:39:49');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `annonce`
--
ALTER TABLE `annonce`
  ADD CONSTRAINT `id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `avis`
--
ALTER TABLE `avis`
  ADD CONSTRAINT `id_user_avis` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_user_b` FOREIGN KEY (`id_user_b`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `conv`
--
ALTER TABLE `conv`
  ADD CONSTRAINT `id_user_b_conv` FOREIGN KEY (`id_user_b`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_user_conv` FOREIGN KEY (`id_user_a`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `id_annonce_b` FOREIGN KEY (`id_annonce`) REFERENCES `annonce` (`id_annonce`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `mesages`
--
ALTER TABLE `mesages`
  ADD CONSTRAINT `id_conv` FOREIGN KEY (`id_conv`) REFERENCES `conv` (`id_conv`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `re_id_user_encore` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
