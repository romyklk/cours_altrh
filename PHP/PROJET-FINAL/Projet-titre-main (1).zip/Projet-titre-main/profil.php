<?php require_once('common/header.php'); 


$pseudo = isset($_GET['pseudo']) ? $_GET['pseudo'] : '';

if(!isset($_GET['pseudo'])) {
    header('Location: index.php');
    exit;
}

if(isset($_GET['action'])){
    $action = $_GET['action'];
} else {
    $action = NULL;
}

if($action == 'avis'){
    require_once('common/avis.php');
}




$query = $db->prepare('SELECT * FROM user WHERE pseudo = :pseudo');
$query->bindValue(':pseudo', $pseudo, PDO::PARAM_STR);
$query->execute();
$userPseudo = $query->rowcount();


if ($userPseudo == 0) {
    header('location: index.php');
    exit;
}

$user = $query->fetch(PDO::FETCH_ASSOC);
?>

<?php
// je veux afficher le profil de l'utilisateur
// je veux afficher les annonces de l'utilisateur
// je veux afficher les commentaires de l'utilisateur


$query = $db->prepare('SELECT * FROM annonce WHERE id_user = :id_user');
$query->bindValue(':id_user', $user['id_user'], PDO::PARAM_INT);
$query->execute();
$annonces = $query->fetchAll(PDO::FETCH_ASSOC);

// $query = $db->prepare('SELECT * FROM commentaire WHERE id_user = :id_user');
// $query->bindValue(':id_user', $user['id_user'], PDO::PARAM_INT);
// $query->execute();
// $commentaires = $query->fetchAll(PDO::FETCH_ASSOC);





?>

<div class="container mt-3">
    <div class="row">
        <div class="col-4">
            <div class="row border border-success rounded">
                <div class="col-4 g-0">
                    <img src="https://via.placeholder.com/150" alt="image de profil" class="img-fluid rounded">
                </div>
                <div class="col-8 d-flex flex-column justify-content-center align-items-center">
                    <h3><?= $user['pseudo'] ?></h3>
                    <p class="text-danger fst-italic"><?= $user['mail'] ?></p>
                    <p class="text-success">Membre depuis le <?php // je ne récupére que la date :
                    $date = explode(' ', $user['createdAt']);
                    // on récupére les différentes parties de la date :
                    $date = explode('-', $date[0]);
                    // on reconstruit la date :
                    $mois = mois($date[1]);
                    $date = $date[2] . ' ' . $mois . ' ' . $date[0];
                    echo $date;
                    ?></p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <h3 class="text-center">Avis sur <?= $user['pseudo'] ?></h3>
                </div>
            </div>
            <div class="row border border-success rounded">
                <div class="col-12  text-center">
                    <?php if (!isLogged()) : ?>
                    <p class="btn btn-danger m-2">Vous devez être connecter pour laisser un avis</p>
                    <?php else : ?>
                    <a class="btn btn-success m-2" href="<?=$nomFichier?>&action=avis">Laisser un avis</a>
                    <a class="btn btn-primary m-2" href="<?= 'message.php?id='. $user['id_user'] .'">'?>Envoyer un message</a>
                    <?php endif; ?>
                </div>
                <?php 
                $query = $db->prepare('SELECT * FROM avis WHERE id_user_b = :id_user');
                $query->bindValue(':id_user', $user['id_user'], PDO::PARAM_INT);
                $query->execute();
                $avis = $query->fetchAll(PDO::FETCH_ASSOC);

                
                
                foreach($avis as $avi) { 
                    $query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id_user');
                    $query->bindValue(':id_user', $avi['id_user'], PDO::PARAM_INT);
                    $query->execute();
                    $pseudoUtil = $query->fetch(PDO::FETCH_ASSOC);
                    

                    echo '<div class="col-12 border-top border-success">';
                    echo '<p class="text-center">' . etoiles($avi['etoiles']) . '</p>';
                    echo '<b class="text-center">' . $pseudoUtil['pseudo'] . '</b>';
                    echo '<p class="text-center">' . $avi['avis'] . '</p>';
                    echo '</div>';
                }?>

                
            </div>
        </div>
        <div class="col-1"></div>
            <div class="col-7">
                <div class="row border border-success rounded">
                    <div class="col-12">
                        <h3 class="text-center">Annonces de <?= $user['pseudo'] ?></h3>
                    </div>
                    <div class="d-flex flex-row flex-wrap justify-content-center">   
                        <?php foreach($annonces as $annonce) { 
                        $query = $db->prepare('SELECT * FROM images WHERE id_annonce = :annonce_id');
                        $query->bindValue(':annonce_id', $annonce['id_annonce'], PDO::PARAM_INT);
                        $query->execute();
                        $image = $query->fetch(PDO::FETCH_ASSOC);
                        ?>
                        <div class="">
                            <div class="card" style="width: 18rem; margin: 2rem">
                                <img src="<?=$image['chemin_image']?>" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?= $annonce['titre'] ?></h5>
                                    <a href="annonce.php?id=<?= $annonce['id_annonce'] ?>" class="btn btn-success">Voir l'annonce</a>
                                </div>
                            </div>
                        </div>
                        
                    <?php } ?>
                    </div> 
                </div>
            </div>
    </div>
</div>




<?php require_once('common/footer.php'); ?>