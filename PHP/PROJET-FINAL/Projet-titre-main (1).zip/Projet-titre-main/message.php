<?php require_once('common/header.php');
if(!isLogged()) {
    echo '<h3> Vous devez être connecté pour envoyer des messages </h3>';
} else {

    

    $id_user_a = $_SESSION['user']['id'];
    $id_user_b = $_GET['id'];

    if($id_user_a == $id_user_b) {
        header('Location: index.php');
        exit;
    }
    
    $query = $db->prepare('SELECT * FROM conv WHERE id_user_a = :id_user_a AND id_user_b = :id_user_b');
    $query->bindValue(':id_user_a', $id_user_a, PDO::PARAM_INT);
    $query->bindValue(':id_user_b', $id_user_b, PDO::PARAM_INT);
    $query->execute();
    $conv = $query->rowCount();
    $id_conv = $query->fetch(PDO::FETCH_ASSOC);
    $query = $db->prepare('SELECT * FROM conv WHERE id_user_a = :id_user_b AND id_user_b = :id_user_a');
    $query->bindValue(':id_user_a', $id_user_a, PDO::PARAM_INT);
    $query->bindValue(':id_user_b', $id_user_b, PDO::PARAM_INT);
    $query->execute();
    $conv2 = $query->rowCount();
    $id_conv2 = $query->fetch(PDO::FETCH_ASSOC);

    if ($conv == 0 && $conv2 == 0) {
        $query = $db->prepare('INSERT INTO conv (id_user_a, id_user_b) VALUES (:id_user_a, :id_user_b)');
        $query->bindValue(':id_user_a', $id_user_a, PDO::PARAM_INT);
        $query->bindValue(':id_user_b', $id_user_b, PDO::PARAM_INT);
        $query->execute();
        $query = $db->prepare('SELECT id_conv FROM conv WHERE id_user_a = :id_user_a AND id_user_b = :id_user_b');
        $query->bindValue(':id_user_a', $id_user_a, PDO::PARAM_INT);
        $query->bindValue(':id_user_b', $id_user_b, PDO::PARAM_INT);
        $query->execute();
        $id_conv = $query->fetch(PDO::FETCH_ASSOC);
        $id_conv = $id_conv['id_conv'];
        $idProfil = $id_user_b;
    } else {
        if ($conv !== 0) {
            $id_conv = $id_conv['id_conv'];
            $idProfil = $id_user_b;
        } 
        if ($conv2 !== 0) {
            $id_conv = $id_conv2['id_conv'];
            $idProfil = $id_user_a;
        }
    }
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $message = isset($_POST['message']) ? $_POST['message'] : '';
        $errors = [];
        if(empty($message)){
            $errors['message'] = "Le message est obligatoire";
        }
        if(empty($errors)){
            $query = $db->prepare('INSERT INTO mesages (id_conv, id_user, contenu) VALUES (:id_conv, :id_user, :contenu)');
            $query->bindValue(':id_conv', $id_conv, PDO::PARAM_INT);
            $query->bindValue(':id_user', $id_user_a, PDO::PARAM_INT);
            $query->bindValue(':contenu', $message, PDO::PARAM_STR);
            $query->execute();

            header('Location: message.php?id='.$id_user_b);
        }
    }
}
$query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id_user');
$query->bindValue(':id_user', $id_user_b, PDO::PARAM_INT);
$query->execute();
$convPseudo = $query->fetch(PDO::FETCH_ASSOC);
$convPseudo = $convPseudo['pseudo'];
?>

<div class="lienProfil">
    <a href="profil.php?pseudo=<?= $convPseudo ?>" class="">
    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
        <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
    </svg>
    <p class="text-uppercase"> <?= $convPseudo ?> </p>

    </a>
</div>




<div class="container">
<?php 
$query = $db->prepare('SELECT * FROM mesages WHERE id_conv = :id_conv');
$query->bindValue(':id_conv', $id_conv, PDO::PARAM_INT);
$query->execute();
$messages = $query->fetchAll(PDO::FETCH_ASSOC);
echo '<div class="container mb-3">';
echo '<div class="row">';
$test = 1;
foreach($messages as $message) { 
    $query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id_user');
    $query->bindValue(':id_user', $message['id_user'], PDO::PARAM_INT);
    $query->execute();
    $convPseudo = $query->fetch(PDO::FETCH_ASSOC);
    $convPseudo = $convPseudo['pseudo'];

    if ($message['id_user'] == $_SESSION['user']['id']) {
        $convPseudo = 'Vous';
        $align = 'ms-auto' ;
        $color = 'success';
        $fond = 'bg-success-subtle';
    } else {
        $align = 'ml-auto' ;
        $color = 'primary';
        $fond = 'bg-primary-subtle';
    }

    ?>

    <div class="col-8 mt-2 <?= $align ?>">
        <div class="card <?= $fond ?>">
            <a href="<?php 
            if ($convPseudo == 'Vous') {
                echo 'compte.php';
            } else {
                echo 'profil.php?pseudo='.$convPseudo;
            }
            ?>" class="badge rounded-pill text-bg-<?= $color ?> mx-auto mt-2 text-uppercase text-decoration-none" style="width:fit-content"><?= $convPseudo; ?></a>
            <div class="card-body">
                <p class="card-text <?php if($convPseudo == 'Vous'){echo 'text-end';} ?>"><?php echo $message['contenu']; ?></p>
            </div>
    </div>
    </div>

    <?php

}
echo '</div>';
echo '</div>';
?>
</div>
<form method="post">
<div class="container">
    <div class="row">
        <div class="col-10">
            <div class="form-group">
                <textarea name="message" class="form-control" id="message" rows="4" placeholder="Quel est votre message ?"></textarea>
            </div>
        </div>
        <div class="col-2 d-flex align-items-center justify-content-end">
            <button type="submit" class="btn btn-success">Envoyer</button>
        </div>
    </div>
</div>
</form>


<?php require_once('common/footer.php'); ?>