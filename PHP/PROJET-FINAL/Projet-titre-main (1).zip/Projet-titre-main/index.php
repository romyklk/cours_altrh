<?php require_once('common/header.php'); 

// on affiche toutes les offres :
$query = $db->query('SELECT * FROM annonce');
$annonces = $query->fetchAll(PDO::FETCH_ASSOC);

echo '<div class="container mt-3">';
foreach ($annonces as $key => $annonce) {
    echo '<div class="row mb-5 border border-success rounded p-3">';
    echo '<div class="col-4">';
    $query = $db->prepare('SELECT * FROM images WHERE id_annonce = :annonce_id');
    $query->bindValue(':annonce_id', $annonce['id_annonce'], PDO::PARAM_INT);
    $query->execute();
    $image = $query->fetch(PDO::FETCH_ASSOC);
    echo '<img src="' . $image['chemin_image'] . '" class="img-fluid rounded" alt="Responsive image">';
    echo '</div>';
    echo '<div class="col-8 d-flex flex-column align-items-center justify-content-between">';
    echo '<h3>' . $annonce['titre'] . '</h3>';
    echo '<p>' . $annonce['description'] . '</p>';
    echo '<p> Prix : '. $annonce['price'] . '€</p>';
    echo '<a href="annonce.php?id=' . $annonce['id_annonce'] . '" class="btn btn-success">Voir l\'annonce</a>';
    echo '</div>';
    echo '</div>';

}
echo "  </div>";
?>


<?php require_once('common/footer.php'); ?>

