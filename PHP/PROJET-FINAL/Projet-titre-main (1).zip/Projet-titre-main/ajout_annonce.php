<?php require_once('common/header.php'); 

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach($_POST as $key => $value){
        $_POST[$key] = htmlspecialchars(addslashes($value));
    }
    
    $titre = isset($_POST['titre']) ? $_POST['titre'] : '';
    $categorie = isset($_POST['categorie']) ? $_POST['categorie'] : '';
    $prix = isset($_POST['prix']) ? $_POST['prix'] : '';
    $description = isset($_POST['description']) ? $_POST['description'] : '';

    // Traitement du formulaire

    $errors = [];

    $showMessage = '';

    // B - Validation du formulaire
    if (empty($titre)) {
        $errors['titre'] = "Le titre est obligatoire";
    }

    if (empty($categorie)) {
        $errors['categorie'] = "La categorie est obligatoire";
    }
    if (empty($prix)) {
        $errors['prix'] = "Le prix est obligatoire";
    }

    if (empty($description)) {
        $errors['description'] = "La description est obligatoire";
    } elseif (strlen($description) < 20) {
        $errors['description'] = "Le description doit faire au moins 10 caractères";
    }

    if (empty($errors)) {

        $query = $db->prepare('SELECT titre FROM annonce WHERE titre = :titre');
        $query->bindValue(':titre', $titre, PDO::PARAM_STR);
        $query->execute();
        $annonce = $query->fetch(PDO::FETCH_ASSOC);

        if ($annonce) {
            $errors['titre'] = "Ce titre existe déjà";
            // on supprime l'image :
        } else {
            // Gestion de l'image
    if(!empty($_FILES['image']['name'])){

        $tabExt = ['jpg', 'png', 'jpeg']; // Les extensions de fichiers autorisées

        $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $extension = strtolower($extension);

        if (!in_array($extension, $tabExt)) {
            $errors['image'] = "L'extension n'est pas valide";
        } elseif ($_FILES['image']['size'] > 2000000) {
            $errors['image'] = "L'image ne doit pas dépasser 2Mo";
        } else {
            $nomImage = bin2hex(random_bytes(16)) . '.' . $extension;
            $chemin_image = "images/$nomImage";
            move_uploaded_file($_FILES['image']['tmp_name'], $chemin_image);


            $id_user = $_SESSION['user']['id'];
            $query = $db->prepare('INSERT INTO annonce (titre, categorie,description,id_user,price) VALUES (:titre,:categorie,:description,:id_user,:price)');
            $query->bindValue(':titre', $titre, PDO::PARAM_STR);
            $query->bindValue(':categorie', $categorie, PDO::PARAM_STR);
            $query->bindValue(':description', $description, PDO::PARAM_STR);
            $query->bindValue(':id_user', $id_user, PDO::PARAM_INT);
            $query->bindValue(':price', $prix, PDO::PARAM_INT);
        
        
            if ($query->execute()) {
                $showMessage .= '<div class="alert alert-success">L\'article a été ajouté</div>';
            } else {
                $showMessage .= '<div class="alert alert-danger">Une erreur est survenue</div>';
            }
        
            $query = $db->prepare('SELECT id_annonce FROM annonce WHERE titre = :titre');
            $query->bindValue(':titre', $titre, PDO::PARAM_STR);
            $query->execute();
            $annonce = $query->fetch(PDO::FETCH_ASSOC);
        
            $id_annonce = $annonce['id_annonce'];
        
                $query = $db->prepare('INSERT INTO images (chemin_image, id_annonce) VALUES (:nom_image, :id_annonce)');
            $query->bindValue(':nom_image', $chemin_image, PDO::PARAM_STR);
            $query->bindValue(':id_annonce', $id_annonce, PDO::PARAM_INT);
            $query->execute();
        
        }
        
    }}}}





if(!isLogged()) :
    
?>


<h3 class="text-center">Vous devez etre connecté pour poster une annonce</h3>

<?php else : ?>

<div class="container p-3 mt-3 rounded bg-success-subtle" >
    <h3 class="text-center">Postez votre annonce</h3>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="titre">Titre</label>
                <input type="text" class="form-control" id="annonce" placeholder="Titre de votre annonce" name="titre">
            <?php if (isset($errors['titre'])) : ?>
                <div class="alert alert-danger"><?= $errors['titre'] ?></div>
            <?php endif; ?>
                    
            </div>
            <div class="mb-3">
                <label for="categorie">Categorie</label>
                <select class="form-select" name="categorie">
                    <option value="Autres">Autres</option>
                <option value="vehicule">Véhicules</option>
                    <option value="immobilier">Immobilier</option>
                    <option value="vacances">Vacances</option>
                    <option value="multimedia">Multimédia</option>
                    <option value="Maison">Maison</option>
                    <option value="Loisirs">Loisirs</option>
                    <option value="Matériel professionnel">Matériel professionnel</option>
                    <option value="Services">Services</option>
                    
                </select>
                <?php if (isset($errors['categorie'])) : ?>
                <div class="alert alert-danger"><?= $errors['categorie'] ?></div>
            <?php endif; ?> 
            </div>
            <div class="mb-3">
                <label for="prix">Prix</label>
                <input type="number" class="form-control" id="prix" placeholder="Entrez votre prix" name="prix">
                <?php if (isset($errors['prix'])) : ?>
                <div class="alert alert-danger"><?= $errors['prix'] ?></div>
            <?php endif; ?> 
            </div>
            <div class="mb-3">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" rows="3" name="description" placeholder="Décrivez votre article"></textarea>
                <?php if (isset($errors['description'])) : ?>
                <div class="alert alert-danger"><?= $errors['description'] ?></div>
            <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="formFileMultiple" class="form-label">Images</label>
                <input class="form-control" type="file" id="formFileMultiple" name="image">
                <?php if (isset($errors['image'])) : ?>
                <div class="alert alert-danger"><?= $errors['image'] ?></div>
            <?php endif; ?>
            </div>
            <div class="d-flex justify-content-between">
                <a class="btn btn-danger" href="index.php">Retour</a>
                <button type="submit" class="btn btn-success">Poster</button>
                
            </div>
            
        </form>
</div>
        
<?php endif; ?>





<?php require_once('common/footer.php'); ?>

