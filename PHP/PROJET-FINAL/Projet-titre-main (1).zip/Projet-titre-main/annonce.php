<?php require_once('common/header.php'); 

$query = $db->prepare('SELECT * FROM annonce WHERE id_annonce = :id_annonce');
$query->bindValue(':id_annonce', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$annonce = $query->rowcount();

if (empty($_GET['id'])) {
    header('Location: index.php');
    exit();
} elseif($annonce == 0) {
    header('Location: index.php');
    exit();
}
else {
    $query = $db->prepare('SELECT * FROM annonce WHERE id_annonce = :id');
    $query->bindValue(':id', $_GET['id'], PDO::PARAM_INT);
    $query->execute();
    $annonce = $query->fetch(PDO::FETCH_ASSOC);

    $query = $db->prepare('SELECT * FROM user WHERE id_user = :id_user');
    $query->bindValue(':id_user', $annonce['id_user'], PDO::PARAM_INT);
    $query->execute();
    $user = $query->fetch(PDO::FETCH_ASSOC);
}

// on affiche l'annonce :
echo '<div class="container mt-3">';
echo '<div class="row mb-5 border border-success rounded p-3">';
echo '<div class="col-4">';
$query = $db->prepare('SELECT * FROM images WHERE id_annonce = :annonce_id');
$query->bindValue(':annonce_id', $annonce['id_annonce'], PDO::PARAM_INT);
$query->execute();
$image = $query->fetch(PDO::FETCH_ASSOC);
echo '<img src="' . $image['chemin_image'] . '" class="img-fluid rounded" alt="Responsive image">';
echo '</div>';
echo '<div class="col-2 d-flex flex-column align-items-center justify-content-center">';
echo '<a class="text-center bg-success-subtle rounded p-3" href="profil.php?pseudo=' . $user['pseudo'] .'" style="text-decoration: none; color: black">Vendeur : ' . $user['pseudo'] . '</a>';
echo '</div>';
echo '<div class="col-6 d-flex flex-column align-items-center justify-content-between">';
echo '<h3>' . $annonce['titre'] . '</h3>';
echo '<p>' . $annonce['description'] . '</p>';
echo '<p> Prix : '. $annonce['price'] . '€</p>';
echo '<a href="message.php?id='. $user['id_user'] . '" class="btn btn-success col-6">Envoyer un message</a>';
echo '<a href="index.php" class="btn btn-danger col-6">Retour</a>';
echo '</div>';
echo '</div>';



?>