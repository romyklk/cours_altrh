user : id_user, Nom, prenom, pseudo, mail, mdp

annonce : id_user_annonce, titre, catégorie, description, date

avis: ID_avis, id_user_postant, id_user_recevant, contenu, date

message: Id annonce, Id_user, clé, message, date

pages :

Accueil (index)

Ajout annonce (ajout_article.php)

annonce (annonce.php)

profil (profil.php)
profil prive (profil_prive.php) -> bouton pour aller au message

message (message.php)

cet aprem :
inscription, connexion, profil (prive et public), modif profil

demain :
avis, annonce (publier, afficher detail et index)

mercredi :
message

bonus : -responsive - cookie rester connecté

a faire :
message dans profil
compte :

- modif et suppr annonce
- voir conv
- voir et suppr avis posté
- voir avis sur nous
