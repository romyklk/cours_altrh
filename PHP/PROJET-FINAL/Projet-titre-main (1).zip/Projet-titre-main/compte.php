<?php require_once('common/header.php'); 

if(!isLogged()){
    header('Location: index.php');
}

if(isset($_GET['action'])){
    $action = $_GET['action'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach($_POST as $key => $value){
        $_POST[$key] = htmlspecialchars(addslashes($value));
    }

    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
    $pseudo = isset($_POST['pseudo']) ? $_POST['pseudo'] : '';
    $email = isset($_POST['mail']) ? $_POST['mail'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (empty($name)) {
        $name = $_SESSION['user']['name'];
    }
    if (empty($firstname)) {
        $firstname = $_SESSION['user']['firstname'];
    }
    if (empty($pseudo)) {
        $pseudo = $_SESSION['user']['pseudo'];
    }
    if (empty($email)) {
        $email = $_SESSION['user']['mail'];
    }
    if (empty($password)) {
        header ("Location: $nomFichier?action=");
    }



    if (password_verify($password, $_SESSION['user']['password'])) {
        $query = $db->prepare('UPDATE user SET name = :name, firstname = :firstname, pseudo = :pseudo, mail = :email WHERE id_user = :id');
        $query->bindValue(':name', $name);
        $query->bindValue(':firstname', $firstname);
        $query->bindValue(':pseudo', $pseudo);
        $query->bindValue(':email', $email);
        $query->bindValue(':id', $_SESSION['user']['id']);
        $query->execute();

        // on update la session
        $_SESSION['user'] = [
            'id' => $_SESSION['user']['id'],
            'name' => $name,
            'firstname' => $firstname,
            'pseudo' => $pseudo,
            'mail' => $email,
            'password' => $password,
            'createdAt' => $_SESSION['user']['createdAt']
        ];
        header("Location: $nomFichier?action=");
    }
    
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if($_GET['action'] == 'supprimer'){
        $query = $db->prepare('DELETE FROM annonce WHERE id_annonce = :id_annonce');
        $query->bindValue(':id_annonce', $_GET['id'], PDO::PARAM_INT);
        $query->execute();
        $nomPage = str_replace("?", "", strstr($nomFichier, "?", true));
        
        header("Location: $nomPage");

        
    }
    if($_GET['action'] == 'modifier'){
        $query = $db->prepare('SELECT price FROM annonce WHERE id_annonce = :id_annonce');
        $query->bindValue(':id_annonce', $_GET['id'], PDO::PARAM_INT);
        $query->execute();
        $cout = $query->fetch(PDO::FETCH_ASSOC);
        $cout = $cout['price'];
        $prix = isset($_POST['prix']) ? $_POST['prix'] : $cout;

        if(!empty($prix)){
            $query = $db->prepare('UPDATE annonce SET price = :prix WHERE id_annonce = :id_annonce');
            $query->bindValue(':id_annonce', $_GET['id'], PDO::PARAM_INT);
            $query->bindValue(':prix', $prix);
            $query->execute();

            $nomPage = str_replace("?", "", strstr($nomFichier, "?", true));
            
            
            header("Location: $nomPage");
    }
    }
    
}

?>

<div class="container">
    <div class="row text-center">
        <h3 class="display-1 my-3">
            Mon compte
        </h3>
    </div>
<?php if($action == 'modifier') : ?>
    <div class="row">
        <div class="card">
            <h5 class="card-header">Modifier mes infos</h5>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="firstname">Prénom</label>
                        <input type="text" class="form-control" id="firstname" placeholder="Entrez votre prénom" name="firstname" value="<?=$_SESSION['user']['firstname']?>">
                    <div class="mb-3">
                        <label for="name">Nom</label>
                        <input type="text" class="form-control" id="name" placeholder="Entrez votre nom" name="name" value="<?=$_SESSION['user']['name']?>">
                    <div class="mb-3">
                        <label for="pseudo">Pseudo</label>
                        <input type="text" class="form-control" id="pseudo" placeholder="Entrez votre pseudo" name="pseudo" value="<?=$_SESSION['user']['pseudo']?>"> 
                    </div>
                    <div class="mb-3">
                        <label for="mail">Adresse mail</label>
                        <input type="email" class="form-control" id="mail" placeholder="Entrez votre adresse mail" name="mail" value="<?=$_SESSION['user']['mail']?>">
                    </div>
                    <div class="mb-3">
                        <label for="password">Ancien mot de passe</label>
                        <input type="password" class="form-control" id="password" placeholder="Entrez votre mot de passe" name="password">
                    </div>
                    <button type="submit" class="btn btn-primary">Modifier</button>
                </form>
            </div>
        </div>
    </div>
<?php else : ?>    
    <div class="row">
        <div class="card">
            <h5 class="card-header">Vos Infos</h5>
            <div class="card-body">
                <h5 class="card-title">
                    <?= $_SESSION['user']['firstname'] . ' ' . $_SESSION['user']['name']; ?>
                </h5>
                <p class="card-text">
                    <?= $_SESSION['user']['pseudo']; ?>
                <p class="card-text">
                    <?= $_SESSION['user']['mail']; ?>
                </p>
                <p>
                    Membre depuis le <?= $_SESSION['user']['createdAt']; ?>
                </p>
                <a href="<?=$nomFichier?>?action=modifier" class="btn btn-primary">Modifier mes infos</a>
            </div>
        </div>
    </div>
<?php endif; ?>
</div>


<div class="container mt-5">
    <div class="row">
        <div class="col-4" id="annonces">
        <h4 class="text-center"> Mes annonces</h4>
            <?php // on récupère les annonces de l'user :
            $query = $db->prepare('SELECT * FROM annonce WHERE id_user = :id');
            $query->bindValue(':id', $_SESSION['user']['id']);
            $query->execute();
            $annonces = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach($annonces as $annonce) {
                $query = $db->prepare('SELECT chemin_image FROM images WHERE id_annonce = :id');
                $query->bindValue(':id', $annonce['id_annonce']);
                $query->execute();
                $images = $query->fetchAll(PDO::FETCH_ASSOC);
                $image = $images[0]['chemin_image'];
                echo '<div class="card mb-3" id="annonce' . $annonce['id_annonce'] . '">';
                echo '<div class="card-body">';
                echo '<img src="' . $image . '" class="img-fluid" alt="...">';
                echo '<h5 class="card-title">' . $annonce['titre'] . '</h5>';
                echo '<p class="card-text">' . $annonce['description'] . '</p>';
                if (isset($_GET['action']) && $_GET['action'] == 'modifier') {
                    echo '<form method="POST">';
                    echo '<input name="prix" value="">';
                    echo '<button type="submit" class="btn btn-primary">Modifier</button>';
                    echo '</form>';
                } else {
                echo '<p class="card-text">' . $annonce['price'] . '€</p>';
                echo '<a href="' . $nomFichier . '?action=modifier&id=' . $annonce['id_annonce'] . '" class="btn btn-primary">Modifier</a>';
                echo '<a href="' . $nomFichier . '?action=supprimer&id=' . $annonce['id_annonce'] .'" class="btn btn-danger">Supprimer</a>';
                }
                echo '</div>';
                echo '</div>';
            }
            
            ?>
        </div>
        <div class="col-4" id="conv">
            <h4 class="text-center"> Mes conversations</h4>
            <ul class="list-group">
                <?php
                    $query = $db->prepare('SELECT * FROM conv WHERE id_user_a = :id OR id_user_b = :id');
                    $query->bindValue(':id', $_SESSION['user']['id']);
                    $query->execute();
                    $convs = $query->fetchAll(PDO::FETCH_ASSOC);
                    foreach($convs as $conv)
                    {
                        if ($conv['id_user_a'] == $_SESSION['user']['id']) {
                            $id_user = $conv['id_user_b'];
                        } else {
                            $id_user = $conv['id_user_a'];
                        }
                        $query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id');
                        $query->bindValue(':id', $id_user);
                        $query->execute();
                        $pseudo = $query->fetch(PDO::FETCH_ASSOC);
                        echo '<li class="list-group-item d-flex justify-content-center"><a  class="link-success link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover text-center text-uppercase" href="message.php?id='. $id_user .'">' . $pseudo['pseudo'] . '</a></li>';
                    }
                ?>
            </ul>

            <h4 class="text-center mt-3"> Leurs avis </h4>
            <?php
            // on récupère les avis de l'user :
            $query = $db->prepare('SELECT * FROM avis WHERE id_user_b = :id');
            $query->bindValue(':id', $_SESSION['user']['id']);
            $query->execute();
            $avis = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach($avis as $avi) {
                $query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id');
                $query->bindValue(':id', $avi['id_user']);
                $query->execute();
                $pseudo = $query->fetch(PDO::FETCH_ASSOC);
                echo '<div class="card mb-3" id="annonce' . $avi['id_avis'] . '">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . 'Avis de : ' . $pseudo['pseudo'] . '</h5>';
                echo '<p class="card-text">' . $avi['avis'] . '</p>';
                echo '<p class="card-text">' . etoiles($avi['etoiles']) . '</p>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>
        <div class="col-4" id="avis">
        <h4 class="text-center"> Mes avis déposés </h4>
            <?php 
            // on récupère les avis de l'user :
            $query = $db->prepare('SELECT * FROM avis WHERE id_user = :id');
            $query->bindValue(':id', $_SESSION['user']['id']);
            $query->execute();
            $avis = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach($avis as $avi) {
                $query = $db->prepare('SELECT pseudo FROM user WHERE id_user = :id');
                $query->bindValue(':id', $avi['id_user_b']);
                $query->execute();
                $pseudo = $query->fetch(PDO::FETCH_ASSOC);
                echo '<div class="card mb-3" id="annonce' . $avi['id_avis'] . '">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . 'Avis sur : ' . $pseudo['pseudo'] . '</h5>';
                echo '<p class="card-text">' . $avi['avis'] . '</p>';
                echo '<p class="card-text">' . etoiles($avi['etoiles']) . '</p>';
                echo '</div>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</div>



<?php require_once('common/footer.php'); ?>

